$(document).ready(function() {
    let count=0;
    const createlist = (todoob) => {
    		count++;
    		let li = document.createElement('li');
    		li.className = 'listitem';

    		let inpcheck = document.createElement('input');
    		inpcheck.type = "checkbox";
    		inpcheck.name = "id";
    		inpcheck.value = count;
    		inpcheck.className="checkbox";

    		let span = document.createElement('span');
    		let spantext = document.createTextNode(todoob.name);
    		span.appendChild(spantext);
    		span.className = 'todoname';

    		let butdel = document.createElement('button');
    		let buttext = document.createTextNode('Delete');
    		butdel.appendChild(buttext);

    		li.appendChild(inpcheck);
    		li.appendChild(span);
    		li.appendChild(butdel);

    		$('#unordertodo').append(li);
    }
    $('#todoname').keyup(function(e){
    	if(e.keyCode === 13){
    		//count++;
    		//console.log(e.target.value);
    		let todoobj = {
    			//'id'   : count,  	
    			'name' : e.target.value,
    			'done' : false
    		}
    		createlist(todoobj);
    		let todolist = [];
    		if(localStorage.getItem('todolist')){
    			todolist = JSON.parse(localStorage.getItem('todolist')); 			
    		}
    		todoobj.id = todolist.length + 1;
    		todolist.push(todoobj);
    		localStorage.setItem('todolist',JSON.stringify(todolist));
    		//console.log(todolist);
    		$('#todoname').val('');
    	}
    });
   /*$('.checkbox').change(function(e){
   		console.log('checked');
   });*/
});